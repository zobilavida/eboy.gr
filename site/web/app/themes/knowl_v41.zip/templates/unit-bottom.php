<div class="module-small bg-dark">
  <div class="container">
<?php dynamic_sidebar('sidebar-footer'); ?>
  </div>
</div>
