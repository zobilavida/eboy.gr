<section class="module-small bg-dark">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-sm-6 col-md-8 col-lg-6 col-lg-offset-2">
        <div class="callout-text font-alt">
          <h3 class="callout-title">Θέλετε να δείτε περισσότερες εργασίες?</h3>
          <p>Είμαστε πάντα διαθεσιμοι, για πιο αναλυτική ενημέρωση.</p>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-2">
        <div class="callout-btn-box"><a class="btn btn-w btn-round" href="portfolio_boxed_gutter_col_3.html">Αναλυτικό portfolio</a></div>
      </div>
    </div>
  </div>
</section>
