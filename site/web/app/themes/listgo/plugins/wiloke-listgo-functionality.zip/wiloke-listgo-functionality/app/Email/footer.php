                                                                </tr>
                                                                <tr>
																	<td height="30" colspan="5"></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											<tr>
												<td height="10" style="margin:0;padding:0;font-size:0;line-height:0;border-bottom:1px solid #dcdbd7"></td>
											</tr>
											<tr>
												<td height="30" style="margin:0;padding:0;font-size:0;line-height:0"></td>
											</tr>
											<tr>
												<td style="color:#7b7771;font:16px/24px 'helvetica neue',helvetica,arial,sans-serif;padding:0;margin:0" valign="top"> </td>
											</tr>
											<tr>
												<td height="40" style="margin:0;padding:0;font-size:0;line-height:0"></td>
											</tr>
											<tr>
												<td align="center">
													<table cellspacing="0" cellpadding="0" border="0">
														<tbody>
														<tr>
															<td align="center" style="color:#8f8a83;font:300 12px/18px 'helvetica neue',helvetica,arial,sans-serif;padding:0;margin:0">
																{{wiloke_signature}}
															</td>
														</tr>
														</tbody>
													</table>
												</td>
											</tr>
											<tr>
												<td align="center">
													<table cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																{{wiloke_social_networks}}
															</tr>
														</tbody>
													</table>
													<br>
													<br>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
								<td width="20" style="margin:0;padding:0;font-size:0;line-height:0">&nbsp;</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>