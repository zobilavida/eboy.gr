<script id="wiloke-price-item" type="text/html">
	<div class="row">
		<div class="col-sm-8">
			<div class="addlisting-popup__field">
				<input type="text" name="name" value="<%= name %>">
			</div>
		</div>
		<div class="col-sm-4">
			<div class="addlisting-popup__field">
				<input type="text" name="price" value="<%= price %>">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="addlisting-popup__field">
				<textarea name="description" id="" cols="30" rows="3"><%= description %></textarea>
			</div>
		</div>
	</div>
</script>