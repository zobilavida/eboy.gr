<td valign="top" width="{{wiloke_column_width}}">
	<table width="{{wiloke_column_width}}" cellspacing="0" cellpadding="0" border="0">
		<tbody>
			{{wiloke_content}}
		</tbody>
	</table>
</td>