<?php
/*
 |--------------------------------------------------------------------------
 | Put hooks and filters here
 |--------------------------------------------------------------------------
 | @since 1.0
 | @author Wiloke
 | @package Wiloke\Themes
 | @subpackage Listgo
 */

namespace WilokeListGoFunctionality\Frontend;

class Handle{
	public function paymentTemplate( $page_template )
	{

	}
}