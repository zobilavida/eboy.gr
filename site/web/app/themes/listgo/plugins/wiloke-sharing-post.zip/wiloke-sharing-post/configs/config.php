<?php
return array(
	'title'      => esc_html__('Sharing Posts', 'wiloke'),
	'attributes' => array(
		'facebook' => array(
			'active'    => true,
			'name_class'=> 'fa fa-facebook',
			'title'     => esc_html__('Facebook', 'wiloke')
		),
		'twitter' => array(
			'active'    => true,
			'name_class'=> 'fa fa-twitter',
			'title'     => esc_html__('Twitter', 'wiloke')
		),
		'googleplus' => array(
			'active'    => true,
			'name_class'=> 'fa fa-google-plus',
			'title'     => esc_html__('Google Plus', 'wiloke')
		),
		'digg' => array(
			'active'    => true,
			'name_class'=> 'fa fa-digg',
			'title'     => esc_html__('Digg', 'wiloke')
		),
		'reddit' => array(
			'active'    => true,
			'name_class'=> 'fa fa-reddit',
			'title'     => esc_html__('Reddit', 'wiloke')
		),
		'linkedin'      => array(
			'active'    => true,
			'name_class'=> 'fa fa-linkedin',
			'title'     => esc_html__('LinkedIn', 'wiloke')
		),
		'stumbleupon'   => array(
			'active'    => true,
			'name_class'=> 'fa fa-stumbleupon',
			'title'     => esc_html__('StumbleUpon', 'wiloke')
		),
		'tumblr'    => array(
			'active'    => true,
			'name_class'=> 'fa fa-tumblr',
			'title'     => esc_html__('Tumblr', 'wiloke')
		),
		'pinterest' => array(
			'active'    => true,
			'name_class'=> 'fa fa-pinterest',
			'title'     => esc_html__('Pinterest', 'wiloke')
		),
		'vk' => array(
			'active'    => true,
			'name_class'=> 'fa fa-vk',
			'title'     => esc_html__('VK', 'wiloke')
		),
		'email' => array(
			'active'    => true,
			'name_class'=> 'fa fa-envelope',
			'title'     => esc_html__('Email', 'wiloke')
		),
		'copylink' => array(
			'active'    => true,
			'name_class'=> 'fa fa-link',
			'title'     => esc_html__('Copy Link', 'wiloke')
		)
	),
	'show_on' => array(
		'home'              => true,
		'archive'           => true,
		'listing'           => true,
		'listing_location'  => true,
		'listing_tag'       => true,
		'post_tag'          => true,
		'listing_cat'       => true,
		'category'          => true,
		'post'              => true,
		'page'              => true
	)
);