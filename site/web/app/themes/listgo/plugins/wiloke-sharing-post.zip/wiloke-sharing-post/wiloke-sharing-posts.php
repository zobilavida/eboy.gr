<?php
/**
 * Plugin Name: Wiloke Sharing Post
 * Plugin URI: http://wiloke.net
 * Description: Wiloke Sharing Post
 * Version: 1.0.2
 * Author: Wiloke
 * Text Domain: wiloke
 * Author URI: http://wiloke.net
 */


if (!defined('ABSPATH')) {
    die("You don't have sufficient permission to access this page");
}

if (!class_exists('WilokeSharingPost')) {
    class WilokeSharingPost {
        public static $aConfigs = array();
        public $aListSettings = array();
        public static $keyOptions = 'wiloke_sharing_posts';
	    public function __construct(){
		    // Add actions
		    add_action('admin_init', array($this, 'adminInit'));
		    add_action('admin_menu', array($this, 'register_submenu'));
		    add_action('admin_init', array($this, 'register_settings'));

		    add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
		    add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));

		    // Add ShortCode
		    add_shortcode('wiloke_sharing_post', array($this, 'renderShortcode'));
	    }

        public function adminInit(){
            self::$aConfigs = include plugin_dir_path(__FILE__) . 'configs/config.php';
            $aDefault = array(
                'home'      => esc_html__('Home', 'wiloke'),
                'archive'   => esc_html__('Archive', 'wiloke')
            );

            $aPostTypes = get_post_types(array(
                'public'   => true,
            ));

            $aTaxonomies = get_taxonomies(array(
	            'public'   => true
            ));

            unset($aPostTypes['attachment']);

            $this->aListSettings = array_merge($aDefault, $aPostTypes, $aTaxonomies);
        }

        public function enqueue_scripts() {
            wp_enqueue_style( 'fontawesome', plugins_url('css/font-awesome.min.css',__FILE__) );
            wp_enqueue_script( 'wiloke-sharing-post', plugins_url('js/wiloke-sharing-post.js',__FILE__), array('jquery'), null, true );
        }

	    public function markup() {

		    global $post;
		    $media = '';
		    if ( has_post_thumbnail($post->ID) )
		    {
			    $media = '&amp;media='.urlencode(get_the_post_thumbnail_url($post->ID, 'medium'));
		    }

            $link = get_permalink($post->ID);
		    $title = $post->post_title;
		    return array(
			    'facebook' => array(
				    'before' => '<a class="share-facebook facebook fb-share-button" href="'.esc_url('https://facebook.com/sharer.php?u='.urlencode($link).'&amp;t='.urlencode($title)).'" data-href="'.esc_url($link).'" target="_blank" title="'.esc_html__('Share on Facebook', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'twitter' => array(
				    'before' => '<a class="share-twitter twitter" href="'.esc_url('https://twitter.com/intent/tweet?text='.urlencode($title) . '-'.urlencode($link).'&amp;source=webclient').'" target="_blank"  title="'.esc_html__('Share on Twitter', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'googleplus' => array(
				    'before' => '<a class="share-googleplus googleplus" href="'.esc_url('http://google.com/bookmarks/mark?op=edit&amp;bkmk='.urlencode($link).'&amp;title='.urlencode($title)).'" target="_blank"  title="'.esc_html__('Share on Google Plus', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'digg' => array(
				    'before' => '<a class="share-digg digg" href="'.esc_url('http://www.digg.com/submit?url='.urlencode($link). '&amp;title='.urlencode($title)).'" target="_blank"  title="'.esc_html__('Share on Digg', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'reddit' => array(
				    'before' => '<a class="share-reddit reddit" href="'.esc_url('http://reddit.com/submit?url='.urlencode($link). '&amp;title='.urlencode($title)).'" target="_blank" title="'.esc_html__('Share on Reddit', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'linkedin' => array(
				    'before' => '<a class="share-linkedin linkedin" href="'.esc_url('http://www.linkedin.com/shareArticle?mini=true&amp;url='.urlencode($link).'&amp;title='.urlencode($title)).'" target="_blank" title="'.esc_html__('Share on LinkedIn', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'stumbleupon' => array(
				    'before' => '<a class="share-stumbleupon stumbleupon" href="'.esc_url('http://www.stumbleupon.com/submit?url='.urlencode($link).'&amp;title='.urlencode($title)).'" target="_blank" title="'.esc_html__('Share on StumbleUpon', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'tumblr' => array(
				    'before' => '<a class="share-tumblr tumblr" href="'.esc_url('http://www.tumblr.com/share/link?url='.urlencode($link) . '&amp;name='.urlencode($title)).'" target="_blank" title="'.esc_html__('Share on Tumblr', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'pinterest' => array(
				    'before' => '<a class="share-pinterest pinterest" href="'.esc_url('https://pinterest.com/pin/create/button/?url='.urlencode($link).$media.'&amp;description='.urlencode($title)).'" target="_blank" data-pin-do="buttonBookmark" title="'.esc_html__('Share on Pinterest', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'vk'=>array(
				    'before' => '<a class="share-vk vk" href="'.esc_url('http://vk.com/share.php?url='.urlencode($link).$media.'&amp;description='.urlencode($title)).'" target="_blank" title="'.esc_html__('Share on VK', 'wiloke').'">',
				    'after' => '</a>'
                ),
			    'email' => array(
				    'before' => '<a class="share-mail mail" href="mailto:?Subject=' . str_replace(' ', '%20', $title) . '&Body=' . str_replace(' ', '%20', sprintf(esc_html__('Click on this link to read the article %s', 'wiloke'), esc_url($link))) . '" title="'.esc_html__('Send this article to an email', 'wiloke').'">',
				    'after' => '</a>'
			    ),
			    'copylink' => array(
				    'before' => '<a class="share-link copy_link" href="#" data-shortlink="'.esc_url(get_permalink($post->ID)).'" title="'.esc_html__('Copy link', 'wiloke').'">',
				    'after' => '</a>'
			    )
		    );
	    }

        public function admin_scripts () {
            wp_enqueue_style( 'wiloke-sharing-admin-fontawesome', plugins_url('css/font-awesome.min.css',__FILE__) );
            wp_enqueue_style( 'wiloke-sharing-admin-main', plugins_url('css/wiloke-sharing-admin.css',__FILE__) );
            wp_enqueue_script( 'wiloke-sharing-admin-main', plugins_url('js/wiloke-sharing-admin.js',__FILE__), array('jquery'), null, true );
        }

        public function register_settings() {
            register_setting( 'wiloke_share_options', 'wiloke_share_options' );
        }

        public function register_submenu () {
            add_submenu_page( 'options-general.php', esc_html__('Wiloke Sharing Posts', 'wiloke'), esc_html__('Wiloke Sharing Posts', 'wiloke'), 'activate_plugins', 'wiloke-sharing-settings', array( $this, 'settings' ) );
        }

        public static function setDefault() {
            $aOptions = get_option(self::$keyOptions);

            if (!$aOptions) {
	            update_option(self::$keyOptions, self::$aConfigs);
            }
        }

        public function renderShortcode() {
            $aOptions = get_option(self::$keyOptions);

            if ( empty($aOptions) ){
                return false;
            }

            if (is_home() && !in_array('home', (array)$aOptions['show_on']))
            {
                return false;
            }else if( is_singular() ){
                global $post;
                if ( !in_array($post->post_type, $aOptions['show_on']) ){
                    return false;
                }
            }else if ( is_tax() ){
                $currentTax = get_queried_object()->taxonomy;
	            if ( !in_array($currentTax, $aOptions['show_on']) ){
		            return false;
	            }
            }elseif (is_archive() && !in_array('archive', (array)$aOptions['show_on']) )
	        {
		        return false;
	        }

            ob_start();
            do_action('wiloke_sharing_posts/action/before_render', $aOptions);

            $aMarkup = $this->markup();
            $cssWrapper = apply_filters('wiloke_sharing_posts/filter/css_wrapper', 'wiloke-sharing-post-social');
            ?>
            <div class="<?php echo esc_attr($cssWrapper); ?>">
                <?php echo apply_filters('wiloke_sharing_posts/filter/title', $aOptions['title']); ?>
                <?php do_action('wiloke_sharing_posts/before_sharing_post_items'); ?>
                <?php
                    foreach($aOptions['attributes'] as $key => $attribute) :
                        if (isset($attribute['active'])) {
                            $social = $aMarkup[$key];

                            if ( has_action('wiloke_sharing_post_filter_social_item') )
                            {
                                do_action('wiloke_sharing_post_filter_social_item', $social['before'], $attribute['name_class'], $attribute['title'], $social['after']);
                            }else{
                                echo $social['before'];
                                    if ( has_filter('wiloke_sharing_posts/filter/social_item') ){
	                                    echo apply_filters('wiloke_sharing_posts/filter/social_item', $attribute);
                                    }else{
	                                    echo sprintf('<i class="%1s" title="%2s">%3s</i>', esc_attr($attribute['name_class']), esc_attr($attribute['title']), $attribute['title']);
                                    }
                                echo $social['after'];
                            }
                        }
                    endforeach;
                ?>
                <?php do_action('wiloke_sharing_posts/after_sharing_post_items'); ?>
            </div>
            <?php
	        do_action('wiloke_sharing_posts/action/after_render', $aOptions);
	        return ob_get_clean();
        }

        public function settings(){
	        if ( isset($_POST['wiloke_share_posts_nonce']) && !empty($_POST['wiloke_share_posts_nonce']) && wp_verify_nonce($_POST['wiloke_share_posts_nonce'], 'wiloke_share_posts_action') ){
	            update_option(self::$keyOptions, $_POST['wiloke_share_options']);

	            if ( isset($_POST['facebook_app_id']) && !empty($_POST['facebook_app_id']) ){
		            $aFbSettings = get_option('_wiloke_facebook_settings');
		            $aFbSettings['app_id'] = $_POST['facebook_app_id'];
		            update_option('_wiloke_facebook_settings', $aFbSettings);
                }
            }
	        $aOptions = get_option(self::$keyOptions);
	        $aOptions = wp_parse_args($aOptions, self::$aConfigs);
	        $aFbSettings = get_option('_wiloke_facebook_settings');
	        $appID = isset($aFbSettings['app_id']) ? $aFbSettings['app_id'] : '';
	        ?>
            <div class="wrap">
                <h2><?php esc_html_e('Settings', 'wiloke'); ?></h2>

                <form action="<?php echo esc_url(admin_url('options-general.php?page=wiloke-sharing-settings')); ?>" method="POST">
                    <?php wp_nonce_field('wiloke_share_posts_action', 'wiloke_share_posts_nonce'); ?>
                    <?php settings_fields('wiloke_share_options'); ?>
                    <table class="form-table wiloke-settings-table">
                        <tr>
                            <th><label for="fbappid" class="wiloke-fbappid"><?php esc_html_e('Facebook App ID', 'wiloke'); ?></label></th>
                            <td>
                                <input id="fbappid" type="text" name="facebook_app_id" value="<?php echo esc_attr($appID); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="title" class="wiloke-show-on-title"><?php esc_html_e('Title', 'wiloke'); ?></label></th>
                            <td>
                                <input id="title" type="text" name="wiloke_share_options[title]" value="<?php echo esc_attr($aOptions['title']); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="wiloke-show-on"><?php esc_html_e('Show sharing posts on', 'wiloke'); ?></label></th>
                            <td>
                                <?php do_action('wiloke_hook_wsp_before_render_show_on', $aOptions); ?>
                                <input type="hidden" name="wiloke_share_options[show_on]" value="" />
                                <?php
                                foreach ( $this->aListSettings as $key => $val ) :
                                ?>
                                    <label for="wiloke_<?php echo esc_attr($key); ?>" class="wiloke-share-label">
                                        <input id="wiloke_<?php echo esc_attr($key); ?>" type="checkbox" name="wiloke_share_options[show_on][<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key,(array)$aOptions['show_on']), 1); ?> />
                                        <?php echo esc_html(str_replace('_', ' ', ucfirst($val))); ?>
                                    </label>
                                <?php
                                endforeach;
                                do_action('wiloke_hook_wsp_after_render_show_on', $aOptions);
                                ?>
                            </td>
                        </tr>

                        <?php foreach($aOptions['attributes'] as $key => $aAtribute) : ?>
                            <tr>
                                <th><label for="wiloke-show-on"><?php echo esc_html($aAtribute['title']); ?></label></th>
                                <td>
                                    <input name="wiloke_share_options[attributes][<?php echo esc_attr($key); ?>][title]" type="hidden" value="<?php echo esc_attr($aAtribute['title']); ?>"/>
                                    <input type="checkbox" name="wiloke_share_options[attributes][<?php echo esc_attr($key); ?>][active]" value="active" <?php checked(in_array('active',(array)$aAtribute), 1); ?>>
                                    <input class="" type="text" name="wiloke_share_options[attributes][<?php echo esc_attr($key); ?>][name_class]" value="<?php echo esc_attr($aAtribute['name_class']); ?>"/>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php submit_button(); ?>
                </form>
            </div>
        <?php
        }
    }
}
new WilokeSharingPost;

add_action( 'plugins_loaded', 'pi_sp_load_textdomain' );
register_activation_hook( __FILE__, array('WilokeSharingPost', 'setDefault' ));
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function pi_sp_load_textdomain() {
  load_plugin_textdomain( 'wiloke', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}
