/*
 Media Upload
 @author: HungPham
 @team: wiloke
 */

(function(factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD
		define(['jquery'], factory);
	} else if (typeof exports === 'object') {
		// CommonJS
		factory(require('jquery'));
	} else {
		// Browser globals
		factory(jQuery);
	}
}(function($) {

	var WilokeWpMedia  = function(element, options) {
		this.$element   = $(element);
		this.options    = $.extend({}, WilokeWpMedia.defaults, options);
		this.buttonAdd  = this.options.buttonAdd;
		this.buttonRemove  = this.options.buttonRemove;
		this.id      = this.options.id;
		this.screen     = this.options.screen;
		this.multiple       = this.options.multiple;
		this.init();
	};

	WilokeWpMedia.defaults  = {
		buttonAdd: '.wil-media-add',
		buttonRemove: '.wil-media-remove',
		id: '.wil-media-id',
		screen: '.wil-media-screen',
		multiple: true
	};

	WilokeWpMedia.prototype.init = function() {
		this.addMedia();
		this.removeAll();
		this.removeItem();
	}

	WilokeWpMedia.prototype.removeAll = function() {
		var _this = this;

		$(_this.buttonRemove, _this.$element).on('click', function(event) {
			event.preventDefault();

			$(_this.id, _this.$element).val('');
			$(_this.screen, _this.$element).html('');

		});
	}

	WilokeWpMedia.prototype.removeItem = function() {

		var _this = this;

		$(_this.screen, _this.$element).on('click', 'span', function(event) {
			event.preventDefault();

			var $this = $(this),
				id = $this.data('id'),
				ids = $(_this.id, _this.$element).val();

			ids = ids.split(',');

			ids.splice( ids.indexOf( id.toString()) , 1);

			$this.closest('.wil-media-screen-item').remove();

			$(_this.id, _this.$element).val(ids.join());

		});
	}

	WilokeWpMedia.prototype.addMedia = function() {
		var _this = this,
			frame;

		$(this.buttonAdd, this.$element).on('click', function(event) {
			event.preventDefault();

			if (frame) {
				frame.open();
				return;
			}

			//Extend the wp.media object
			frame = wp.media({
				title: 'Insert Media',
				button: {
					text: 'Insert'
				},
				multiple: _this.multiple  // Set to true to allow multiple files to be selected
			});

			frame.on('select', function() {
				console.log(frame.state());
				// Get media attachment details from the frame state
				var attachment, html = '', ids = [];

				attachment = frame.state().get('selection').toJSON();

				$.each(attachment, function(index, item) {
					html += '<li class="wil-media-screen-item" style="background-image: url('+ item.url +')">';
					html += '<span class="wil-media-screen-item-remove" data-id="'+ item.id +'"></span>';
					html += '</li>';
					ids.push(item.id);
				});

				$(_this.id, _this.$element).val(ids.join());
				$(_this.screen, _this.$element).html(html);

			});

			//Open the uploader dialog
			frame.open();
		});

	}

	$.fn.WilokeWpMedia = function(options) {
		return this.each(function() {
			new WilokeWpMedia(this, options);
		});
	};

}));


/*
 Icon Picker
 @author: HungPham
 @team: wiloke
 */

(function(factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD
		define(['jquery'], factory);
	} else if (typeof exports === 'object') {
		// CommonJS
		factory(require('jquery'));
	} else {
		// Browser globals
		factory(jQuery);
	}
}(function($) {

	var WilokeIconPicker = function(element, options) {
		this.$element   = $(element);
		this.options    = $.extend({}, WilokeIconPicker.defaults, options);
		this.icon       = this.options.icon;
		this.button     = this.options.button;
		this.target     = this.options.target;
		this.search     = this.options.search;
		this.list       = this.options.list;
		this.url    = this.options.url;
		this.data       = this.options.data;
		this.init();
	};

	WilokeIconPicker.defaults  = {
		icon: '.wil-icon-selected',
		button: '.wil-icon-button',
		target: '.wil-icon-value',
		search: '.wil-icon-search-input',
		list: '.wil-icon-list',
		url: '',
		data: ''
	};

	WilokeIconPicker.prototype.init = function() {
		this.onSearch();
		this.onDropdown();
		this.onSelected();
	}

	WilokeIconPicker.prototype.onDropdown = function() {

		var _this = this;

		$(this.button, this.$element).on('click', function(event) {
			event.preventDefault();

			if( !_this.$element.hasClass('is-ajaxed') ) {
				_this.getAjax();
			} else {

				var current = _this.$element.find(_this.target).val();

				if(current =='' ) {
					_this.$element.find('.selected').removeClass('selected');
				}
			}

			_this.$element.toggleClass('is-dropdown');

		});

		$(document).on('click', function(event) {

			if(!$(event.target).closest(_this.$element).length) {
				_this.$element.removeClass('is-dropdown');
			}

		});
	}

	WilokeIconPicker.prototype.onSearch = function() {

		var $list = $(this.list, this.$element),
			$search = $(this.search, this.$element),
			timeout;

		$search.on('keyup', function(event) {

			var s = $(this).val();

			if(timeout) {
				clearTimeout(timeout);
			}

			if(s.length) {

				timeout = setTimeout(function() {

					$('li', $list).each(function(index, el) {

						var $this = $(this),
							title = $this.data('name');

						if(title && title.search(s) === -1) {
							$this.addClass('hidden');
						} else {
							$this.removeClass('hidden');
						}

					});

					clearTimeout(timeout);

				}, 100);

			} else {
				$('li', $list).removeClass('hidden');
			}
		});
	}

	WilokeIconPicker.prototype.getAjax = function() {

		var _this = this,
			current = _this.$element.find(_this.target).val();

		if( _this.$element.hasClass('is-ajax') ) {
			return;
		}

		$.ajax({
			url: _this.url,
			type: 'POST',
			data: _this.data,
			beforeSend: function(res) {
				_this.$element.addClass('is-ajax');
				_this.$element.find(_this.list).addClass('loading');
			},
			success: function(res) {

				if(res) {

					data = JSON.parse(res);

					if(data.length) {

						_this.$element.find(_this.list).append('<li data-value=""><i></i></li>');

						$.each(data, function(index, el) {

							for (var i in el) {
								var selected = (current && current == i) ? 'selected' : '';
								$html = '<li class="'+ selected +'" data-value="'+ i +'" data-name="'+ el[i] +'" title="'+ el[i] +'"><i class="'+ i +'"></i></li>';
								_this.$element.find(_this.list).append($html);
							}
						});
					}
				}

				_this.$element.removeClass('is-ajax').addClass('is-ajaxed');
				_this.$element.find(_this.list).removeClass('loading');
			}
		});

	}

	WilokeIconPicker.prototype.onSelected = function() {

		var _this = this;

		$(_this.list,_this.$element).on('click', 'li', function(event) {
			event.preventDefault();

			var $this = $(this),
				value = $this.data('value');

			if(value) {
				$(_this.target, _this.$element).val(value);
			} else {
				$(_this.target, _this.$element).val('');
			}

			$(_this.search, _this.$element).val('');
			$(_this.list +' li',_this.$element).removeClass('hidden');
			$(_this.icon + ' i', _this.$element).attr('class', value);
			_this.$element.removeClass('is-dropdown');

		});
	}

	$.fn.WilokeIconPicker = function(options) {
		return this.each(function() {
			new WilokeIconPicker(this, options);
		});
	};

}));



(function($) {
	"use strict";

	iconPickers();
	function iconPickers() {
		var $el = $(this);
		if($el.length) {
			$el.each(function() {
				iconPicker($(this));
			});
		}
	}

	wilokeWpMedias();
	function wilokeWpMedias() {
		if($('.wil-media').length) {

			$('.wil-media').each(function(index, el) {

				var $el = $(this),
					multiple = $el.data('multiple');

				wilokeWpMedia($el, multiple);
			});
		}
	}

	function iconPicker($el) {
		$el.WilokeIconPicker({
			url: ajaxurl,
			data: {
				action: 'wiloke_icon_list',
				security: $el.data('nonce')
			}
		});
	}

	function colorPicker($el) {
		$el.wpColorPicker();
	}

	function wilokeWpMedia($el) {
		$el.WilokeWpMedia({
			multiple: $el.data('multiple')
		});
	}

	navMenuSettings();
	function navMenuSettings() {

		var $el = $($('#wiloke-nav-setting').html());

		$('#update-nav-menu').find('.menu-settings').append($el);

		$el.find('.wil-menu-enable').on('change', function(event) {

			var $this = $(this);

			if( $this.is(':checked') ) {
				$el.find('.wil-menu-select').addClass('active')
			} else {
				$el.find('.wil-menu-select').removeClass('active')
			}
		});
	}

	// Dependence
	wilokeDependences();
	function wilokeDependences() {
		var $el = $('.metabox-menu');
		if($el.length ) {
			wilokeDependence($el);
		}
	}

	function wilokeDependence($el) {

		$el.find('[data-dependence]').each(function(index, el) {

			var self = $(this),
				name = self.data('dependence'),
				value = self.data('value'),
				$target = $('[name="'+ name +'"]');

			if( $target.length ) {

				$target.on('change', function(event) {

					var that = $(this),
						currentValue = that.val();

					if( value.indexOf(currentValue) !== -1) {
						self.css('display', '');
					} else {
						self.css('display', 'none');
					}

				}).trigger('change');
			}

		});
	}

	// Popup setting
	var wilokeFrames = [];

	var WilokeMegaMenuBuilder = function(el) {

		this.el = el;
		this.menuId = $('#update-nav-menu #menu').val();
		this.template = $($('#wiloke-mega-menu-builder').html());
		this.itemId = this.el.find('input.menu-item-data-db-id').val();
		this.title = this.el.find('.menu-item-title').text();
		this.nonce = this.el.data('nonce');
		this.url = this.template.find('.wiloke-mega-menu-builder-form').attr('action');
		this.init();
	}

	WilokeMegaMenuBuilder.prototype = {

		init: function() {
			this.create();
			this.changeTabs();
			this.save();
			this.cancel();
			this.open();
		},

		create: function() {
			if( $.inArray(this.menuId) === -1 ) {
				this.createSetting();
				this.createContent();
				this.template.find('.wiloke-mega-menu-builder-name').html(this.title);
				this.template.attr('id', 'wiloke-mega-menu-builder-' + this.itemId);
				$('body').append(this.template);
				wilokeFrames.push(this.menuId);
			}
		},

		createContent: function() {

			var _this = this;

			var iframe = $('<iframe>', {
				src: _this.url + '&menu_id=' + _this.menuId + '&menu_item_id=' + _this.itemId,
				class: 'wiloke-mega-menu-builder-iframe'
			});

			_this.template.find('#wiloke-mega-menu-builder-content').addClass('loading');

			iframe.load(function() {
				_this.template.find('#wiloke-mega-menu-builder-content').removeClass('loading');
			});

			_this.template.find('#wiloke-mega-menu-builder-content').html(iframe);
		},

		createSetting: function() {
			var _this = this;

			$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: {
						action: 'wiloke_nav_item_settings',
						post_id: _this.itemId,
						security: _this.nonce
					},
					beforeSend: function() {
						_this.template.find('#wiloke-mega-menu-builder-settings').addClass('loading');
					}
				})
				.done(function(resp) {
					if(resp && resp.status === 200) {

						var html = $(resp.data);

						// IconPicker
						html.find('.wil-icon-select').each(function(index, el) {
							iconPicker($(this));
						});

						// Media
						html.find('.wil-media').each(function(index, el) {
							iconPicker($(this));
						});

						// Color
						html.find('.color-picker').each(function(index, el) {
							colorPicker($(this));
						});

						// Dependence
						html.find('.metabox-menu').each(function(index, el) {
							wilokeDependence($(this));
						});

						_this.template.find('#wiloke-mega-menu-builder-settings').html(html);
					}

					_this.template.find('#wiloke-mega-menu-builder-settings').removeClass('loading');

				});
		},

		open: function() {
			this.template.addClass('wiloke-mega-menu-builder-open');
		},

		close: function() {
			this.template.removeClass('wiloke-mega-menu-builder-open');
		},

		changeTabs: function() {

			var _this = this;

			_this.template.on('click', '.wiloke-mega-menu-builder-tab a', function(event) {

				event.preventDefault();

				var self = $(this),
					panel = self.attr('href');

				if( !self.hasClass('active') ) {
					_this.template.find('.wiloke-mega-menu-builder-tab a').removeClass('active');
					_this.template.find('.wiloke-mega-menu-builder-panel').removeClass('active');

					self.addClass('active');
					_this.template.find(panel).addClass('active');
				}

			});
		},

		save: function() {

			var _this = this;

			_this.template.find('.wiloke-mega-menu-builder-form').submit(function(event) {
				event.preventDefault();

				var self = $(this),
					data = self.serializeObject(),
					content = _this.template.find('.wiloke-mega-menu-builder-iframe').contents().find('textarea[name="content"]').val();

				data['content'] = content;

				$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wiloke_nav_item_save',
							post_id: _this.itemId,
							data: data,
							security: _this.nonce
						},
						beforeSend: function() {
							_this.template.find('.wiloke-mega-menu-builder-panel').addClass('loading');
						}
					})
					.done(function(resp) {

						if(resp) {

							if(typeof data['megamenu'] !== 'undefined') {
								_this.el.find('.wil-menu-item-setting').addClass('active');
							} else {
								_this.el.find('.wil-menu-item-setting').removeClass('active');
							}

							_this.close();

						} else {
							console.log('Error');
						}

						_this.template.find('.wiloke-mega-menu-builder-panel').removeClass('loading');
					})

			});
		},

		cancel: function() {
			var _this = this;

			_this.template.on('click', '.wiloke-mega-menu-builder-cancel', function(event) {
				event.preventDefault();
				_this.close();
			});
		}
	}

	$.fn.WilokeMegaMenuBuilder = function() {

		return this.each(function () {

			var self = $(this),
				data = self.data('WilokeMegaMenuBuilder');

			if (!data) {
				data = new WilokeMegaMenuBuilder(self);
				self.data('WilokeMegaMenuBuilder', data);
			}

		});
	};

	$('#menu-to-edit').on('click', '.wil-menu-item-setting', function(event) {

		var self = $(this),
			el = self.closest('li.menu-item');

		if(el.data('WilokeMegaMenuBuilder')) {
			var _el = el.data('WilokeMegaMenuBuilder');
			_el.open();
		} else {
			el.WilokeMegaMenuBuilder();
		}


	});

})(jQuery);