<?php

if (!function_exists('wiloke_mega_menu_shortcode_instagram')) {

    add_shortcode('wiloke_mega_menu_shortcode_instagram', 'wiloke_mega_menu_shortcode_instagram');

    function wiloke_mega_menu_shortcode_instagram($atts)
    {

        $atts = wp_parse_args($atts, array(
            'username'   		=> '',
            'number'     		=> 4,
            'display'    		=> 'grid',
            'xl_per_row'	 	=> 5,
            'lg_per_row'	 	=> 4,
            'md_per_row'	 	=> 3,
            'sm_per_row'	 	=> 2,
            'xs_per_row'	 	=> 1,
            'space'		 		=> 20,
            'nav'				=> '',
            'dots'				=> '',
            'target'     		=> '_blank',
            'size'       		=> 'small',
            'el_class'   		=> '',
            'el_css'     		=> '',
        ));

        ob_start();

        $username = $atts['username'];

        if( empty($username) ) {

            $aInstagramSettings   = get_option('_pi_instagram_settings');

            if ($aInstagramSettings) {
                $username = $aInstagramSettings['username']; 
            }

        }

        if ( !empty($username) ):

            $attribute = '';

            $class     = 'wiloke-menu-' . $atts['display'];

            if ($atts['display'] == 'grid') {
                $class .= ' wiloke-menu-col-xl-' . $atts['xl_per_row'];
                $class .= ' wiloke-menu-col-lg-' . $atts['lg_per_row'];
                $class .= ' wiloke-menu-col-md-' . $atts['md_per_row'];
                $class .= ' wiloke-menu-col-sm-' . $atts['sm_per_row'];
                $class .= ' wiloke-menu-col-xs-' . $atts['xs_per_row'];
                $class .= ' wiloke-menu-space-' . $atts['space'];
            }

            if ($atts['display'] == 'slider') {
                $class     .= ' owl-carousel';
                $attribute .= 'data-col-xl="' . esc_attr($atts['xl_per_row']) . '" ';
                $attribute .= 'data-col-lg="' . esc_attr($atts['lg_per_row']) . '" ';
                $attribute .= 'data-col-md="' . esc_attr($atts['md_per_row']) . '" ';
                $attribute .= 'data-col-sm="' . esc_attr($atts['sm_per_row']) . '" ';
                $attribute .= 'data-col-xs="' . esc_attr($atts['xs_per_row']) . '" ';
                $attribute .= 'data-space="'. esc_attr($atts['space']) .'" ';
                $attribute .= 'data-nav="' . esc_attr(filter_var($atts['nav'], FILTER_VALIDATE_BOOLEAN)) . '" ';
                $attribute .= 'data-dots="' . esc_attr(filter_var($atts['dots'], FILTER_VALIDATE_BOOLEAN)) . '" ';
            }

            if (!empty($atts['el_class'])) {
                $class .= ' ' . $atts['el_class'];
            }

            $class .= vc_shortcode_custom_css_class($atts['el_css']);

            $medias = wiloke_mega_menu_get_instagram($username);?>

			<div class="wiloke-menu-photos wiloke-menu-maginific <?php echo esc_attr(trim($class)) ?>" <?php print trim($attribute) ?>>

				<?php if (is_wp_error($medias)): ?>

                    <p><?php echo wp_kses_post($medias->get_error_message()); ?></p>

                <?php else: ?>

    				<?php 
                        $medias = array_slice($medias, 0, $atts['number']);
                    ?>

                	<?php foreach ($medias as $media): ?>

            	    	<div class="wiloke-menu-photo">
            	    	    <a href="<?php echo esc_url($media['original']) ?>" target="<?php echo esc_attr($atts['target']) ?>">
                                <img alt="<?php echo esc_attr($media['description']) ?>" data-src="<?php echo esc_url($media[$atts['size']]) ?>" class="lazy">
            	    	    </a>
            	    	</div>

                	<?php endforeach?>

                <?php endif?>

			</div>

        <?php endif;

        return ob_get_clean();
    }
}
