<?php

if (!function_exists('wiloke_mega_menu_shortcode_posts')) {

    add_shortcode('wiloke_mega_menu_shortcode_posts', 'wiloke_mega_menu_shortcode_posts');

    function wiloke_mega_menu_shortcode_posts($atts)
    {

        $atts = wp_parse_args($atts, array(
            'post_type'      => 'post',
            'posts_per_page' => 4,
            'order'          => 'DESC',
            'orderby'        => 'date',
            'show_comments'  => '',
            'show_date'      => '',
            'display'        => 'grid',
            'xl_per_row'        => 5,
            'lg_per_row'        => 4,
            'md_per_row'        => 3,
            'sm_per_row'        => 2,
            'xs_per_row'        => 1,
            'space'             => 20,
            'nav'               => '',
            'dots'              => '',
            'el_class'       => '',
            'el_css'         => '',
        ));

        $args = array(
            'ignore_sticky_posts' => true,
            'order'               => $atts['order'],
            'orderby'             => $atts['orderby'],
            'post_type'           => $atts['post_type'],
            'posts_per_page'      => $atts['posts_per_page'],
        );

        $query = new WP_Query($args);

        ob_start();

        if ($query->have_posts()):

        	$attribute = '';
            $class     = 'wiloke-menu-' . $atts['display'];

            if ($atts['display'] == 'grid') {
                $class .= ' wiloke-menu-col-xl-' . $atts['xl_per_row'];
                $class .= ' wiloke-menu-col-lg-' . $atts['lg_per_row'];
                $class .= ' wiloke-menu-col-md-' . $atts['md_per_row'];
                $class .= ' wiloke-menu-col-sm-' . $atts['sm_per_row'];
                $class .= ' wiloke-menu-col-xs-' . $atts['xs_per_row'];
                $class .= ' wiloke-menu-space-' . $atts['space'];
            }

            if ($atts['display'] == 'slider') {
                $class     .= ' owl-carousel';
                $attribute .= 'data-col-xl="' . esc_attr($atts['xl_per_row']) . '" ';
                $attribute .= 'data-col-lg="' . esc_attr($atts['lg_per_row']) . '" ';
                $attribute .= 'data-col-md="' . esc_attr($atts['md_per_row']) . '" ';
                $attribute .= 'data-col-sm="' . esc_attr($atts['sm_per_row']) . '" ';
                $attribute .= 'data-col-xs="' . esc_attr($atts['xs_per_row']) . '" ';
                $attribute .= 'data-space="'. esc_attr($atts['space']) .'" ';
                $attribute .= 'data-nav="' . esc_attr(filter_var($atts['nav'], FILTER_VALIDATE_BOOLEAN)) . '" ';
                $attribute .= 'data-dots="' . esc_attr(filter_var($atts['dots'], FILTER_VALIDATE_BOOLEAN)) . '" ';
            }

            if (!empty($atts['el_class'])) {
                $class .= ' ' . $atts['el_class'];
            }

            $class_img = $atts['display'] == 'slider' ?  'owl-lazy' : 'lazy'; 

            $class .= vc_shortcode_custom_css_class($atts['el_css']); ?>

			<div class="wiloke-menu-posts <?php echo esc_attr(trim($class)) ?>" <?php print $attribute; ?>>

				<?php while ($query->have_posts()): $query->the_post();?>

					<div class="wiloke-menu-post">

						<?php if (has_post_thumbnail()): ?>

							<div class="wiloke-menu-post__thumbnail">
								<a href="<?php the_permalink()?>" title="<?php the_title()?>">
                                    <img data-src="<?php the_post_thumbnail_url('medium') ?>" alt="" class="<?php echo esc_attr($class_img); ?>">
								</a>
							</div>

                        <?php endif?>

						<div class="wiloke-menu-post__body">

							<h2 class="wiloke-menu-post__title"><a href="<?php the_permalink()?>" title="<?php the_title()?>"><?php the_title();?></a></h2>

                            <?php if ( !empty($atts['show_date']) || !empty($atts['show_comments']) ): ?>
                                
    							<div class="wiloke-menu-post__meta">

    								<?php if (!empty($atts['show_date'])): ?>
    									<span class="wiloke-menu-post__date">
    										<span class="wiloke-menu-post__label"><i class="fa fa-calendar-minus-o"></i></span>
    										<span class="wiloke-menu-post__text"><?php the_date();?></span>
    									</span>
    								<?php endif?>

    								<?php if (!empty($atts['show_comments'])): ?>
    									<span class="wiloke-menu-post__comments">
    										<span class="wiloke-menu-post__label"><i class="fa fa-comments-o"></i></span>
    										<span class="wiloke-menu-post__text"><a href="<?php the_permalink()?>#comments""><?php comments_number();?></a></span>
    									</span>
    								<?php endif?>

                                </div>

                            <?php endif ?>
                            
                        </div>

                    </div>

                <?php endwhile?>

			</div>

        <?php endif;

        return ob_get_clean();
    }
}
