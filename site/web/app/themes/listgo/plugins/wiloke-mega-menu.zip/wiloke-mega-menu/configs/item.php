<?php

$args = array(

    array(
        'type'  => 'checkbox',
        'name'  => 'megamenu',
	    'std'   => 0,
        'title' => esc_html__('Mega Menu', 'wiloke-menu'),
    ),

    array(
        'type'   => 'select',
        'name'   => 'align',
        'title'  => esc_html__('Menu Position', 'wiloke-menu'),
        'value'  => 'right',
        'option' => array(
            'left'   => esc_html__('Left', 'wiloke-menu'),
            'right'  => esc_html__('Right', 'wiloke-menu'),
            'center' => esc_html__('Center', 'wiloke-menu'),
        ),
        'desc'   => esc_html__('This setting is only available for Horizontal Menu', 'wiloke-menu'),
    ),

    array(
        'type'  => 'number',
        'name'  => 'width',
        'title' => esc_html__('Menu Width', 'wiloke-menu'),
        'value' => 1200,
        'desc'  => esc_html__('Set the width for this menu item.', 'wiloke-menu'),
    ),

    array(
        'type'  => 'iconpicker',
        'name'  => 'icon',
        'title' => esc_html__('Menu Icon', 'wiloke-menu'),
        'value' => ''
    ),

    array(
        'type'  => 'color',
        'name'  => 'background_color',
        'title' => esc_html__('Background Color', 'wiloke-menu'),
        'value' => ''
    )
);
