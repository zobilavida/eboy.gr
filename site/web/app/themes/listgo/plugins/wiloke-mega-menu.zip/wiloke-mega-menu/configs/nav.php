<?php

if (!function_exists('wiloke_menu_theme_filter')) {
    function wiloke_menu_theme_filter()
    {
        $arr = array(
            ''                       => esc_html__('Select Theme', 'wiloke-menu'),
            'wiloke-menu-dark'       => esc_html__('Theme Dark', 'wiloke-menu'),
            'wiloke-menu-light'      => esc_html__('Theme Light', 'wiloke-menu'),
            'wiloke-menu-bluelight'  => esc_html__('Theme Blue Light', 'wiloke-menu'),
            'wiloke-menu-darkgray'   => esc_html__('Theme Dark Gray', 'wiloke-menu'),
            'wiloke-menu-lightgreen' => esc_html__('Theme Light Green', 'wiloke-menu'),
            'wiloke-menu-darkgreen'  => esc_html__('Theme Dark Dreen', 'wiloke-menu'),
            'wiloke-menu-orange'     => esc_html__('Theme Orange', 'wiloke-menu'),
            'wiloke-menu-pink'       => esc_html__('Theme Pink', 'wiloke-menu'),
            'wiloke-menu-brown'      => esc_html__('Theme Brown', 'wiloke-menu'),
            'wiloke-menu-darkblue'   => esc_html__('Theme Dark Blue', 'wiloke-menu'),
        );

        $arr = apply_filters('wiloke_menu_theme_filter', $arr);

        return $arr;
    }
}

if (!function_exists('wiloke_menu_style_filter')) {
    function wiloke_menu_style_filter()
    {
        $arr = array(
            'wiloke-menu-horizontal' => esc_html__('Horizontal Menu', 'wiloke-menu'),
            'wiloke-menu-vertical'   => esc_html__('Vertical Menu', 'wiloke-menu'),
        );

        $arr = apply_filters('wiloke_menu_style_filter', $arr);

        return $arr;
    }
}

$args = array(

    array(
        'type'   => 'select',
        'name'   => 'style',
        'title'  => esc_html__('Menu Orientation', 'wiloke-menu'),
        'option' => wiloke_menu_style_filter(),
        'desc'   => esc_html__('The orientation of menu bar.', 'wiloke-menu'),
    ),

    array(
        'type'       => 'select',
        'name'       => 'align_menu',
        'title'      => esc_html__('Vertical Position', 'wiloke-menu'),
        'value'      => 'left',
        'option'     => array(
            'left'  => esc_html__('Left', 'wiloke-menu'),
            'right' => esc_html__('Right', 'wiloke-menu'),
        ),
        'dependence' => array(
            'element' => 'style',
            'value'   => array('wiloke-menu-vertical'),
        ),
    ),

    array(
        'type'  => 'number',
        'name'  => 'breakpoint',
        'title' => esc_html__('Responsive Breakpoint', 'wiloke-menu'),
        'value' => 767,
        'desc'  => esc_html__('Switch to Navbar collapse style when the screen is smaller than or equal to x', 'wiloke-menu'),
    ),

    array(
        'type'   => 'select',
        'name'   => 'trigger',
        'title'  => esc_html__('Drop Sub-menu by', 'wiloke-menu'),
        'value'  => 1,
        'option' => array(
            1 => esc_html__('Hover', 'wiloke-menu'),
            0 => esc_html__('Click', 'wiloke-menu'),
        ),
    ),

    // array(
    //     'type'  => 'text',
    //     'name'  => 'bar_text',
    //     'title' => esc_html__('Toggle Menu Text', 'wiloke-menu'),
    //     'value' => '',
    //     'desc'  => esc_html__('This text will be used as an tooltip', 'wiloke-menu'),
    // ),

    array(
        'type'   => 'select',
        'name'   => 'animate',
        'title'  => esc_html__('Drop-Down Menu Transition', 'wiloke-menu'),
        'value'  => 'fadeIn',
        'option' => wiloke_menu_animates(),
	    'desc'   => ''
    ),

    array(
        'type'   => 'select',
        'name'   => 'theme',
        'title'  => esc_html__('Theme', 'wiloke-menu'),
        'value'  => '',
        'option' => wiloke_menu_theme_filter(),
        'desc'   => esc_html__('Select theme of menu.', 'wiloke-menu'),
    ),
);
