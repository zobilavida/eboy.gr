!function($) {
	$(window).load(function () {
		if ( typeof  vc !== 'undefined' ){
			vc.events.trigger("vc:backend_editor:switch");
		}
	});
}(window.jQuery);