<?php

if (!function_exists('wiloke_mega_menu_shortcode_image_carousel_map')) {

    add_action('vc_before_init', 'wiloke_mega_menu_shortcode_image_carousel_map');

    function wiloke_mega_menu_shortcode_image_carousel_map($atts)
    {

        vc_map(array(
            'name'     => esc_html__('Mega Menu Image Carousel', 'wiloke-menu'),
            'base'     => 'wiloke_mega_menu_shortcode_image_carousel',
            'category' => esc_html__('Wiloke Mega Menu', 'wiloke-menu'),
            'params'   => array(

                array(
                    'type'        => 'attach_images',
                    'heading'     => esc_html__('Images', 'wiloke-menu'),
                    'param_name'  => 'images',
                    'admin_label' => true,
                    'description' => esc_html__('Select images from media library.', 'wiloke-menu'),
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Size', 'wiloke-menu'),
                    'param_name'  => 'size',
                    'admin_label' => true,
                    'std'         => 'medium',
                    'value'       => array(
                        esc_html__('Thumbnail', 'wiloke-menu')    => 'thumbnail',
                        esc_html__('Medium', 'wiloke-menu')       => 'medium',
                        esc_html__('Medium Large', 'wiloke-menu') => 'medium-large',
                        esc_html__('Large', 'wiloke-menu')        => 'large',
                        esc_html__('Original', 'wiloke-menu')     => 'full',
                    ),
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Display', 'wiloke-menu'),
                    'param_name'  => 'display',
                    'admin_label' => true,
                    'value'       => array(
                        esc_html__('Grid', 'wiloke-menu')   => 'grid',
                        esc_html__('Slider', 'wiloke-menu') => 'slider',
                    ),
                    'description' => esc_html__('Display style grid or slider. Default set grid.', 'wiloke-menu'),
                ),

                array(
                    'type'       => 'checkbox',
                    'heading'    => esc_html__('Nav', 'wiloke-menu'),
                    'param_name' => 'nav',
                    'value'      => array(
                        esc_html__('Show next/prev buttons.', 'wiloke-menu') => 'yes',
                    ),
                    'dependency' => array(
                        'element' => 'display',
                        'value'   => array('slider'),
                    ),
                ),

                array(
                    'type'       => 'checkbox',
                    'heading'    => esc_html__('Dots', 'wiloke-menu'),
                    'param_name' => 'dots',
                    'value'      => array(
                        esc_html__('Show dots navigation.', 'wiloke-menu') => 'yes',
                    ),
                    'dependency' => array(
                        'element' => 'display',
                        'value'   => array('slider'),
                    ),
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Items per row (≥1200px)', 'wiloke-menu'),
                    'param_name'  => 'xl_per_row',
                    'std'         => 5,
                    'value'       => array(
                        esc_html__('1', 'wiloke-menu')  => 1,
                        esc_html__('2', 'wiloke-menu')  => 2,
                        esc_html__('3', 'wiloke-menu')  => 3,
                        esc_html__('4', 'wiloke-menu')  => 4,
                        esc_html__('5', 'wiloke-menu')  => 5,
                        esc_html__('6', 'wiloke-menu')  => 6,
                        esc_html__('7', 'wiloke-menu')  => 7,
                        esc_html__('8', 'wiloke-menu')  => 8,
                        esc_html__('9', 'wiloke-menu')  => 9,
                        esc_html__('10', 'wiloke-menu') => 10,
                    )
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Items per row (≥992px)', 'wiloke-menu'),
                    'param_name'  => 'lg_per_row',
                    'std'         => 4,
                    'value'       => array(
                        esc_html__('1', 'wiloke-menu')  => 1,
                        esc_html__('2', 'wiloke-menu')  => 2,
                        esc_html__('3', 'wiloke-menu')  => 3,
                        esc_html__('4', 'wiloke-menu')  => 4,
                        esc_html__('5', 'wiloke-menu')  => 5,
                        esc_html__('6', 'wiloke-menu')  => 6,
                        esc_html__('7', 'wiloke-menu')  => 7,
                        esc_html__('8', 'wiloke-menu')  => 8,
                        esc_html__('9', 'wiloke-menu')  => 9,
                        esc_html__('10', 'wiloke-menu') => 10,
                    )
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Items per row (≥768px)', 'wiloke-menu'),
                    'param_name'  => 'md_per_row',
                    'std'         => 3,
                    'value'       => array(
                        esc_html__('1', 'wiloke-menu')  => 1,
                        esc_html__('2', 'wiloke-menu')  => 2,
                        esc_html__('3', 'wiloke-menu')  => 3,
                        esc_html__('4', 'wiloke-menu')  => 4,
                        esc_html__('5', 'wiloke-menu')  => 5,
                        esc_html__('6', 'wiloke-menu')  => 6,
                        esc_html__('7', 'wiloke-menu')  => 7,
                        esc_html__('8', 'wiloke-menu')  => 8,
                        esc_html__('9', 'wiloke-menu')  => 9,
                        esc_html__('10', 'wiloke-menu') => 10,
                    )
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Items per row (≥576px)', 'wiloke-menu'),
                    'param_name'  => 'sm_per_row',
                    'std'         => 2,
                    'value'       => array(
                        esc_html__('1', 'wiloke-menu')  => 1,
                        esc_html__('2', 'wiloke-menu')  => 2,
                        esc_html__('3', 'wiloke-menu')  => 3,
                        esc_html__('4', 'wiloke-menu')  => 4,
                        esc_html__('5', 'wiloke-menu')  => 5,
                        esc_html__('6', 'wiloke-menu')  => 6,
                        esc_html__('7', 'wiloke-menu')  => 7,
                        esc_html__('8', 'wiloke-menu')  => 8,
                        esc_html__('9', 'wiloke-menu')  => 9,
                        esc_html__('10', 'wiloke-menu') => 10,
                    )
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Items per row (<576px)', 'wiloke-menu'),
                    'param_name'  => 'xs_per_row',
                    'std'         => 1,
                    'value'       => array(
                        esc_html__('1', 'wiloke-menu')  => 1,
                        esc_html__('2', 'wiloke-menu')  => 2,
                        esc_html__('3', 'wiloke-menu')  => 3,
                        esc_html__('4', 'wiloke-menu')  => 4,
                        esc_html__('5', 'wiloke-menu')  => 5,
                        esc_html__('6', 'wiloke-menu')  => 6,
                        esc_html__('7', 'wiloke-menu')  => 7,
                        esc_html__('8', 'wiloke-menu')  => 8,
                        esc_html__('9', 'wiloke-menu')  => 9,
                        esc_html__('10', 'wiloke-menu') => 10,
                    )
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Space', 'wiloke-menu'),
                    'param_name'  => 'space',
                    'std'         => 20,
                    'value'       => array(
                        esc_html__('5', 'wiloke-menu')  => 5,
                        esc_html__('10', 'wiloke-menu') => 10,
                        esc_html__('15', 'wiloke-menu') => 15,
                        esc_html__('20', 'wiloke-menu') => 20,
                        esc_html__('25', 'wiloke-menu') => 25,
                        esc_html__('30', 'wiloke-menu') => 30,
                        esc_html__('35', 'wiloke-menu') => 35,
                        esc_html__('40', 'wiloke-menu') => 40,
                        esc_html__('45', 'wiloke-menu') => 45,
                        esc_html__('50', 'wiloke-menu') => 50,
                    ),
                    'description' => esc_html__('Set space for items.', 'wiloke-menu'),
                ),

                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__('Extra class name', 'wiloke-menu'),
                    'param_name'  => 'el_class',
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'wiloke-menu'),
                ),

                array(
                    'type'       => 'css_editor',
                    'heading'    => esc_html__('CSS box', 'wiloke-menu'),
                    'param_name' => 'el_css',
                    'group'      => esc_html__('Design Options', 'wiloke-menu'),
                ),

            ),
        ));
    }
}
