<?php
/**
 * Template Name: Custom Template
 */
?>
<?php get_template_part('templates/unit', 'hero'); ?>
<?php get_template_part('templates/unit', 'cv'); ?>
<?php get_template_part('templates/unit', 'what_i_do'); ?>
