<section id="home" >
  <div class="container">
   <div class="row text-left align-items-center">
    <div class="col-12">
  <div class="jumbotron jumbotron-fluid mb-0">
      <?
      $post_14 = get_post(14);
$content = $post_14->post_content;
echo $content
?>
     </div>
    </div>
   </div>
  </div>
 </section>
