<section id="about">
<div class="container test">
<div class="row">
  <div class="col-6">
    test
</div>
<div class="col-6">
  test
</div>    
</div>
</div>
 </section>
