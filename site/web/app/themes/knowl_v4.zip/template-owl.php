<?php
/**
 * Template Name: owl
 */
?>
<div class="container">
  <div class="row">
    <div class="col-12">
    <div id="carouselExampleIndicators" class="carousel slide span12" data-ride="carousel">
        <div class="row">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active" ></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
        </div>
        <div class="row">
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                <img class="d-block img-fluid" src="https://placeimg.com/640/480/any" alt="First slide">
                </div>
              <div class="carousel-item">
                    <img class="d-block img-fluid" src="https://placeimg.com/640/480/any" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block img-fluid" src="https://placeimg.com/640/480/any" alt="Third slide">
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
