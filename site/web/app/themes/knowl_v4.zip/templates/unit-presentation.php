<section class="module bg-dark-60 parallax-bg presentation" data-background="assets/images/section-6.jpg">
  <div class="video-player" data-property="{videoURL:'https://www.youtube.com/watch?v=yOSL9L0efhQ', containment:'.presentation', startAt:0, mute:false, autoPlay:false, loop:false, opacity:0.25, showControls:true, showYTLogo:true, vol:25}"></div>

  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="video-box">
          <div class="video-box-icon"><a class="video-pop-up" href="https://eboy.gr/app/uploads/sites/4/2018/01/Alternative_Video_2.mp4"><span class="icon-video"></span></a></div>
          <div class="video-title font-alt">Παρουσίαση</div>
          <div class="video-subtitle font-alt">Δείτε το video της παρουσίασης</div>
        </div>
      </div>
    </div>
  </div>
</section>
