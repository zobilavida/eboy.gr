<?php
/**
 * Template Name: Front
 */
?>
<?php get_template_part('templates/unit', 'hero'); ?>
<?php get_template_part('templates/unit', 'hero_2'); ?>
  <div class="main p-0">
    <?php //get_template_part('templates/unit', 'about'); ?>
    <?php get_template_part('templates/unit', 'features'); ?>
    <hr class="divider-w">
    <?php //get_template_part('templates/unit', 'works_more'); ?>
    <hr class="divider-w">
    <?php get_template_part('templates/unit', 'services'); ?>
    <hr class="divider-w">
    <?php get_template_part('templates/unit', 'europe'); ?>
    <hr class="divider-w">
    <?php get_template_part('templates/unit', 'works'); ?>

    <hr class="divider-w">
    <?php get_template_part('templates/unit', 'team'); ?>
    <hr class="divider-w">
    <?php //get_template_part('templates/unit', 'testimonial'); ?>
    <?php //get_template_part('templates/unit', 'news'); ?>
    <?php //get_template_part('templates/unit', 'subscribe'); ?>
    <?php //get_template_part('templates/unit', 'contact'); ?>


  </div>
